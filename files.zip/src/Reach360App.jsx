import React from 'react'

export default function Reach360App() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-100 to-white">
      <section className="w-full max-w-2xl px-6 py-16 rounded-xl shadow-lg bg-white">
        <h1 className="text-4xl font-extrabold mb-4 text-blue-700">Reach360</h1>
        <p className="mb-8 text-lg text-gray-700">
          Welcome to Reach360 — your complete marketing solution.<br />
          Accelerate your business growth with our all-in-one platform.
        </p>
        <a
          href="#get-started"
          className="inline-block px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700 transition"
        >
          Get Started
        </a>
      </section>
    </main>
  )
}